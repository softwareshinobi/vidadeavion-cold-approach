$(document).ready(function () {

    setTimeout(saveCalendarDetailsToServer, 1000);

    // alert("full calendar");
    // getCalendarDetailsFromServer();
    // setInterval(saveCalendarDetailsToServer, 8000);

});

function getCalendarDetailsFromServer() {

	console.debug("enter -> getCalendarDetailsFromServer");

//////////////////////////////////////////

	$.ajax({

		type: "GET",

		url: upstreamAPIURL + "/intention/",

		crossDomain: true,

		dataType: "text",

		success: function (response, status, jqXHR) {

            console.log("response / " + response);

            intention=response;

            console.log("intention / server / " + intention);

            $("#intention").text(intention);

		},

		error: function (exception, status) {

			console.log("error issuing request");

			console.log("status / " + status);

			console.log("exception / " + exception);

		}

	});

}

function saveCalendarDetailsToServer() {

	console.debug("enter -> saveCalendarDetailsToServer");

 //   calendarData = $(this).data('valorantCalendar');

    // =$("#valorantCalendar").getEvents();

    //  alert("calendarData / " + calendarData);

    // console.debug("calendarData / " + calendarData);

    console.log("valorantCalendar",valorantCalendar);    

    valorantCalendarEvents = valorantCalendar.getEvents()

    console.log("valorantCalendarEvents",valorantCalendarEvents);    

//////////////////////////////////////////

	payload = JSON.stringify({

        intention: valorantCalendarEvents,        

	});

    //alert("payload / ", payload);

//////////////////////////////////////////

	$.ajax({

		type: "POST",

		url: upstreamAPIURL + "/intention/set-intention",

		data: payload,

		contentType: "application/json; charset=utf-8",

		crossDomain: true,

		dataType: "text",

		success: function (response, status, jqXHR) {

            console.log("response / " + response);

            alert(response);

            getUniverseIntention();

		},

		error: function (exception, status) {

			console.log("error issuing request");

			console.log("status / " + status);

			console.log("exception / " + exception);

		}

	});

}
